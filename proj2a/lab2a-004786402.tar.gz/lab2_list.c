//NAME: Joel George
//EMAIL: joelgeorge03@gmail.com
//ID: 004786402


#include "SortedList.h"
#include <getopt.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <signal.h>

char rand_string[1024];
int thread_index_2_element_array = 0; 
pthread_mutex_t lock;
volatile int s_lock = 0;
char sync_mode = 'n';

struct args{
  SortedListElement_t** el_array;
  int it_num;
  int max;
  SortedListElement_t* el_list;
}argument_holder;

void sigseghandler(){
  fprintf(stderr, "SIGSEGV was caught - a bad memory access was attempted. \n\n");
  exit(2);
}
int print_error(){
  fprintf(stderr, "Error:%s\n", strerror(errno));
  exit(1);
}

int error_check(int return_val, int success_val){
  if(return_val != success_val){
    print_error();
    exit(1);
  }
  return 1;
}


int process_options(struct option* option_list, int *option_index, int argc, char* argv[], int *thread_num, int *it_num, char** y_mode){
  int current_character;
  while(1){
    current_character = getopt_long(argc, argv, ":t:i:s:y:", option_list, option_index);
    if(current_character == -1)
      return 0;
    switch(current_character){
    case 't':
      *thread_num = (int) strtol(optarg, NULL, 10);
      break;
    case 'i':
      *it_num = (int) strtol(optarg, NULL, 10);
      break;
    case 's':
      sync_mode = optarg[0];
      break;
    case 'y':
      strcpy(*y_mode, optarg);
      break;
    case ':':
      fprintf(stderr, "Arguments --threads, --iterations, and --sync require arguments.\n");
      exit(1);
      break;
    case '?':
      fprintf(stderr, "The only valid arguments are --threads, --iterations, --sync, and --yield.\n");
      exit(1);
      break;
    }
  }
  return 0;
}

int process_y_mode(char* y_mode, char** y_usage){
  char* insert = strchr(y_mode, 'i');
  char* delete = strchr(y_mode, 'd');
  char* lookup = strchr(y_mode, 'l');
  int yield_options = 0;
  if(insert){
    yield_options = yield_options | 0x01;
    strcat(*y_usage, "i\0");
  }
  if(delete){
    yield_options = yield_options | 0x02;
    strcat(*y_usage, "d\0");
  }
  if(lookup){
    yield_options = yield_options | 0x04;
    strcat(*y_usage, "l\0");
  }
  if(!insert && !delete && !lookup){
    strcat(*y_usage, "none");
  }
  return yield_options;
}

void process_usage(char** usage, char** y_usage){
  char base[14];
  strcpy(base, "list-");
  strcat(base, *y_usage);
  switch(sync_mode){
  case 'n':
    strcat(base, "-none\0");
    strcpy(*usage, base);
    break;
  case 'm':
    strcat(base, "-m\0");
    strcpy(*usage, base);
    int error_val = pthread_mutex_init(&lock, NULL);
    error_check(error_val, 0);
    break;
  case 's':
    strcat(base, "-s\0");
    strcpy(*usage, base);
    break;
  default:
    fprintf(stderr, "Error: invalid --sync argument. The only valid arguments for --sync are m and s.\n");
    break;
 }
}

SortedList_t* create_list_item(const char* key){
  SortedListElement_t* element = malloc(1*sizeof(SortedListElement_t));
  if(!element){
    fprintf(stderr, "Error: %s\n", strerror(errno));
    exit(1);
  }
  element->key = key;
  return element;
}

void rand_string_gen(char** holder){
  char characters[63] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
			 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
			 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 
			 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd',
			 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
			 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x',
			 'y', 'z', '\0'};
  int length = 0;
  int rand_index = 0;
  while(length < 1024 && rand_index < 1024){
    int index = (int) (((double)rand()/RAND_MAX)*62);
    if(index >= 0 && index <= 62){
      rand_string[rand_index] = characters[index];
      length++;
      rand_index++;
    }
  }
  *holder = rand_string;
}

void list_creation(SortedListElement_t** list, int thread_num, int it_num){
  int i = 0;
  int max = thread_num*it_num;
  char* key;
  SortedListElement_t* element;
  for(;i < max; i++){
    rand_string_gen(&key);
    element = create_list_item(key);
    list[i] = element;
  }
}

void *thread_function(void *arg_ptr){
  if(sync_mode == 'm')
    pthread_mutex_lock(&lock);
  else if(sync_mode == 's')
    while(__sync_lock_test_and_set(&s_lock,1));
  int current_thread_index = thread_index_2_element_array;
  SortedListElement_t** element_array = (*((struct args*)arg_ptr)).el_array;
  int iterations = (*((struct args*)arg_ptr)).it_num;
  int max = (*((struct args*)arg_ptr)).max;
  SortedListElement_t* list = ((struct args*)arg_ptr)->el_list;

  int i = 0;

  for(; thread_index_2_element_array < max && i < iterations; thread_index_2_element_array++){
    SortedList_insert(list, element_array[thread_index_2_element_array]);
  }
  if(SortedList_length(list) == -1){
    fprintf(stderr, "An inconsistency in the list was found!\n");
    exit(2);
  }
  for(; current_thread_index < thread_index_2_element_array; current_thread_index++){
    int error_val = SortedList_delete(element_array[current_thread_index]);
    if(error_val != 0){
      fprintf(stderr, "There was an error when deleting from the list!\n");
      exit(2);
    }
  }
  if(sync_mode == 'm')
    pthread_mutex_unlock(&lock);
  else if(sync_mode == 's')
    __sync_lock_release(&s_lock);
  return NULL;
}

void thread_creator(int thread_num, int iterations, pthread_t *thread_array, SortedListElement_t** element_array, SortedListElement_t* list){
  int i = 0;

  argument_holder.el_array = element_array;
  argument_holder.it_num = iterations;
  argument_holder.max = thread_num*iterations;
  argument_holder.el_list = list;
 
  int error_val;
  for(; i < thread_num; i++){
    error_val = pthread_create(&thread_array[i], NULL, thread_function, (void*) &argument_holder);
    error_check(error_val, 0);
  }
}

int main(int argc, char* argv[]){
  //for option parsing
  int option_index = 0;

  //for threads
  int thread_num = 1;
  pthread_t* thread_array;

  //for iterations
  int it_num = 1;

  //for sync
  char* usage = malloc(14*sizeof(char));
  if(!usage){
    fprintf(stderr, "Error: %s\n", strerror(errno));
    exit(1);
  }

  //for yield
  char* y_mode = malloc(4*sizeof(char));
  if(!y_mode){
    fprintf(stderr, "Error: %s\n", strerror(errno));
    exit(1);
  }
  char* y_usage = malloc(5*sizeof(char));
  if(!y_usage){
    fprintf(stderr, "Error: %s\n", strerror(errno));
    exit(1);
  }


  //for lists
  SortedList_t* main_list;
  SortedListElement_t** element_array;
  int list_num = 1;
  int length;

  //CSV info
  long long run_time_val = 0;
  int op_num = 0;
  long long time_per_op = 0;

  static struct option option_list[] = {
    {"threads", required_argument, 0, 't'},
    {"iterations", required_argument, 0, 'i'},
    {"sync", required_argument, 0, 's'},
    {"yield", required_argument, 0, 'y'},
    {0, 0, 0, 0}
  };

  process_options(option_list, &option_index, argc, argv, &thread_num, &it_num, &y_mode);
  opt_yield = process_y_mode(y_mode, &y_usage);
  process_usage(&usage, &y_usage);

  main_list = malloc(sizeof(SortedListElement_t));
  if(!main_list){
    fprintf(stderr, "Error: %s\n", strerror(errno));
    exit(1);
  }

  main_list->next = main_list;
  main_list->prev = main_list;
  main_list->key = NULL;

  thread_array = malloc(thread_num*sizeof(pthread_t));
  if(!thread_array){
    fprintf(stderr, "Error: %s\n", strerror(errno));
    exit(1);
  }


  element_array = malloc(thread_num*it_num*sizeof(SortedListElement_t*));
  if(!element_array){
    fprintf(stderr, "Error: %s\n", strerror(errno));
    exit(1);
  }

  list_creation(element_array, thread_num, it_num);

  struct timespec beginning, end;
  clock_gettime(CLOCK_MONOTONIC, &beginning);
  signal(SIGSEGV, sigseghandler);
  thread_creator(thread_num, it_num, thread_array, element_array, main_list);

  int count = 0;
  for(; count < thread_num; count++){
    pthread_join(thread_array[count], NULL);
  }
  clock_gettime(CLOCK_MONOTONIC, &end);

  length = SortedList_length(main_list);

  if(length != 0){
    fprintf(stderr, "The length was found to be non-zero!\n");
    exit(2);
  }

  run_time_val = end.tv_nsec - beginning.tv_nsec;
  op_num = thread_num*it_num*3;
  time_per_op = run_time_val/op_num;
  printf("%s%s%d%s%d%s%d%s%d%s%llu%s%llu\n",usage, ",", thread_num, ",", it_num, ",", list_num, ",", op_num, ",", run_time_val, ",", time_per_op);
  free(y_mode);
  free(y_usage);
  free(usage);
  free(element_array);
  free(thread_array);
  free(main_list);
  if(sync_mode == 'm')
    pthread_mutex_destroy(&lock);
  exit(0);
}

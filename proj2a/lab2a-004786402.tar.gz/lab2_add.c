//NAME: Joel George
//EMAIL: joelgeorge03@gmail.com
//ID: 004786402

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <getopt.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
//#include <sched.h>

static int opt_yield = 0;
pthread_mutex_t lock; 
volatile int s_lock = 0;
volatile int *cas_lock = 0;

struct args {
  long long* count_pointer;
  int it_num;
  char sync_mode;
}argument_holder;

int print_error(){
  fprintf(stderr, "Error:%s\n", strerror(errno));
  exit(1);
}

int error_check(int return_val, int success_val){
  if(return_val != success_val){
    print_error();
    exit(1);
  }
  return 1;
}

void add(long long *pointer, long long value) {
  long long sum = *pointer + value;
  if(opt_yield){
    int error_val =  sched_yield();
    error_check(error_val, 0);
  }
  *pointer = sum;
}

void add_mutex(long long *pointer, long long value){
  pthread_mutex_lock(&lock);
  long long sum = *pointer + value;
  if(opt_yield){
    int error_val =  sched_yield();
    error_check(error_val, 0);
  }
  *pointer = sum;
  pthread_mutex_unlock(&lock);
}

void add_spin_lock(long long *pointer, long long value){
  while(__sync_lock_test_and_set(&s_lock, 1));  
  
  long long sum = *pointer + value;
  if(opt_yield){
    int error_val =  sched_yield();
    error_check(error_val, 0);
  }
  *pointer = sum;
  
  __sync_lock_release(&s_lock);
}

void add_CAS_lock(long long *pointer, long long value){
  long long former;
  long long sum;
  do{
    former = *pointer;
    sum = *pointer + value;
    if(opt_yield){
      int error_val =  sched_yield();
      error_check(error_val, 0);
    }
    __sync_val_compare_and_swap(pointer, pointer, sum);
  }while(former!=*pointer);
}


void *thread_function(void *args){
  int iterations = (*((struct args*) args)).it_num;
  long long* pointer = (*((struct args*) args)).count_pointer;
  char mode = (*((struct args*) args)).sync_mode;

  int i = 0;
  for(; i < iterations; i++){
    if(mode == 'm')
      add_mutex(pointer, 1);
    else if(mode == 's')
      add_spin_lock(pointer, 1);
    else if(mode == 'c')
      add_CAS_lock(pointer, 1);
    else 
      add(pointer, 1);
  }

  i = 0;
  for(; i < iterations; i++){
    if(mode == 'm')
      add_mutex(pointer,-1);
    else if(mode == 's')
      add_spin_lock(pointer, -1);
    else if(mode == 'c')
      add_CAS_lock(pointer, -1);
    else
      add(pointer, -1);
  }

  return NULL; 
}

int process_options(struct option* option_list, int *option_index, int argc, char* argv[], int *thread_num, int *it_num, char** s_mode){
  int current_character;
  while(1){
    current_character = getopt_long(argc, argv, ":t:i:s:", option_list, option_index);
    if(current_character == -1)
      return 0;
    switch(current_character){
  case 't':
    *thread_num = (int) strtol(optarg, NULL, 10);
    break;
  case 'i':
    *it_num = (int) strtol(optarg, NULL, 10);
    break;
  case 's':
    *s_mode = optarg;
    break;
  case ':':
    fprintf(stderr, "Arguments --threads, --iterations, and --sync require arguments.\n");
    exit(1);
    break;
  case '?':
    fprintf(stderr, "The only valid arguments are --threads, --iterations, --sync, and --yield.\n");
    exit(1);
    break;
    }
  }
  return 0;
}

void thread_creator(int thread_num, int iterations, long long *counter, pthread_t *thread_array, char** s_mode){
 
  int i = 0;

  argument_holder.count_pointer = counter;
  argument_holder.it_num = iterations;
  argument_holder.sync_mode = *(*s_mode);

  int error_val;
  for(; i < thread_num; i++){
    error_val = pthread_create(&thread_array[i], NULL, thread_function, (void *) &argument_holder);
    error_check(error_val, 0);
  }

}

void process_usage(char* s_mode, int opt_yield, char** usage){
  if(opt_yield){
    switch(*s_mode){
    case 'n':
      *usage = "add-yield-none";
      break;
    case 'm':
      *usage = "add-yield-m";
      int error_val = pthread_mutex_init(&lock, NULL);
      error_check(error_val, 0);
      break;
    case 's':
      *usage = "add-yield-s";
      break;
    case 'c':
      *usage = "add-yield-c";
      break;
    default:
      break;
    }
  }
  else{
    switch(*s_mode){
    case 'n':
      *usage = "add-none";
      break;
    case 'm':
      *usage = "add-m";
      int error_val = pthread_mutex_init(&lock, NULL);
      error_check(error_val, 0);
      break;
    case 's':
      *usage = "add-s";
      break;
    case 'c':
      *usage = "add-c";
      break;
    default:
      break;
    }
  }
}

int main(int argc, char* argv[]){
  //for option parsing
  int option_index = 0;

  //for threads
  int thread_num = 1;

  //for iterations
  int it_num = 1;

  //for sync
  char* s_mode = "n";
  char* usage = "add-none";

  //CSV info
  long long run_time_val = 0;
  int op_num = 0;
  long long time_per_op = 0;

  static struct option option_list[] = {
    {"threads", required_argument, 0, 't'},
    {"iterations", required_argument, 0, 'i'},
    {"sync", required_argument, 0, 's'},
    {"yield", no_argument, &opt_yield, 1},
    {0, 0, 0, 0}
  };

  //Processing input arguments
  process_options(option_list, &option_index, argc, argv, &thread_num, &it_num, &s_mode);
  process_usage(s_mode, opt_yield, &usage); 

  long long counter = 0;
  pthread_t *thread_array = malloc(thread_num*sizeof(pthread_t));
  struct timespec beginning, end;

  clock_gettime(CLOCK_MONOTONIC, &beginning);
  thread_creator(thread_num, it_num, &counter, thread_array, &s_mode);
  int count = 0;

  for(; count < thread_num; count++){
    pthread_join(thread_array[count], NULL);
  }

  if(*s_mode == 'm'){
    pthread_mutex_destroy(&lock);
  }

  clock_gettime(CLOCK_MONOTONIC, &end);
  run_time_val = end.tv_nsec - beginning.tv_nsec;
  op_num = thread_num*it_num*2;
  time_per_op = run_time_val/op_num;
  printf("%s%s%d%s%d%s%d%s%llu%s%llu%s%lld\n", usage, ",",thread_num,",", it_num, ",", op_num, ",", run_time_val, ",", time_per_op, ",", counter);

  free(thread_array);
  return 0;
}

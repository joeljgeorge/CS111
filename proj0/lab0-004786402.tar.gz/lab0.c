#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <getopt.h>
#include <sys/stat.h> 
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>

void sigseghandler();
void sigsegactivator();
//TODO: Error checking
int main(int argc, char *argv[]){
  static int segfault = 0;
  static int catch = 0;
  int current_option;
  int option_index = 0;//Source: https://www.gnu.org/software/libc/manual/html_node/Getopt-Long-Option-Example.html
  int input_file_descriptor = 0;
  int output_file_descriptor = 1;
  int new_input_file_descriptor = 0;
  int new_output_file_descriptor = 1;

  static struct option options_list[] = {//Source: https://www.gnu.org/softw\are/libc/manual/html_node/Getopt-Long-Option-Example.html
    {"input", required_argument, 0, 'i'},
    {"output", required_argument, 0, 'o'},
    {"segfault", no_argument, &segfault, 1},
    {"catch", no_argument, &catch, 1},
    {0, 0, 0, 0}
  };

  while(1){//Source: https://www.gnu.org/software/libc/manual/html_node/Getopt-Long-Option-Example.html
    current_option = getopt_long(argc, argv, ":i:o:", options_list, &option_index);
    if(current_option == -1)//we've reached the end of the options list
      break;
    switch(current_option){
    case 0://Flag was set for either segmentation or catch
      //TODO: do stuff depending on what flag was tripped
      if(segfault || catch)
	break;
    case 'i':
      input_file_descriptor = open(optarg, O_RDONLY);
      if(input_file_descriptor >= 0){
	if(close(0) == -1){
	  fprintf(stderr, "Error closing standard input: %s\n", strerror(errno));
	}
	new_input_file_descriptor = dup(input_file_descriptor);
	if(new_input_file_descriptor == -1){
	  fprintf(stderr, "Error duplicating input file: %s\n", strerror(errno));
	}
	if(close(input_file_descriptor) == -1){
          fprintf(stderr, "Error closing input file: %s\n", strerror(errno));
        }
      }
      if(input_file_descriptor == -1){
	fprintf(stderr, "Error with the file given for input argument: %s\n", strerror(errno));
	exit(2);
      }
      break;
    case 'o':
      output_file_descriptor = creat(optarg, S_IRWXU | S_IRWXO | S_IRWXG);
      if(output_file_descriptor >= 0){
	if(close(1) == -1){
	  fprintf(stderr, "Error closing standard output: %s\n", strerror(errno));
	}
	new_output_file_descriptor = dup(output_file_descriptor);
	if(new_output_file_descriptor == -1){
          fprintf(stderr, "Error duplicating output file: %s\n", strerror(errno));
        }
        if(close(output_file_descriptor) == -1){
          fprintf(stderr, "Error closing output file: %s\n", strerror(errno));
        }
      }
      if(output_file_descriptor == -1){
        fprintf(stderr, "Error with the file given for output argument: %s\n", strerror(errno));
        exit(3);
      }
      break;
    case '?':
      fprintf(stderr, "%s", "The only valid arguments are --input=filename, --output=filename, --segfault, and --catch. You can use any combination of these arguments, but no other additional arguments.\n");
      exit(1);
    case ':':
      fprintf(stderr, "%s", "Expected a filename after input/output argument.\n");
      exit(1);
    }
  }
  if(catch){
    signal(SIGSEGV, sigseghandler);
  }
  if(segfault){
    //TODO: error checking close file?
    sigsegactivator();
  }
  //TODO: implement segfault stuff
  //SOURCE: sfrobu.c file from CS35L project
  int read_status = 1;
  char holder = ' ';
  /*int input_buf_size = 10;
  char* input_buffer = malloc(input_buf_size*sizeof(char));
  char *temp = NULL;
  int chars_read = 0;*/
  while(read_status != 0){
    /*if((chars_read+1)>input_buf_size){
      input_buf_size*=2;
      temp = realloc(input_buffer, input_buf_size*sizeof(char));
      input_buffer = temp;
      temp = NULL;
    }
    read_status = read(input_file_descriptor, input_buffer + chars_read, 1);
    chars_read++; */
    read_status = read(new_input_file_descriptor, &holder, 1);
    if(read_status == 0)//TODO: error checking
      break;
    else{
      write(new_output_file_descriptor, &holder, 1); 
    }
  }
  close(new_input_file_descriptor);
  close(new_output_file_descriptor);
  exit(0);
}

void sigseghandler(){
  fprintf(stderr, "SIGSEGV was caught - a bad memory access was attempted. \n");
  exit(4);
}
void sigsegactivator(){
  char* seg_pointer = NULL;
  if(*seg_pointer == 'f'){
    printf("%s", "This will fail");
  } 
}

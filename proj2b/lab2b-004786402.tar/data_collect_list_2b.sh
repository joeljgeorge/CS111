./lab2_list --iterations=1000 --threads=1 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=2 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=8 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=12 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=16 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=24 --sync=m >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=1 --sync=s >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=2 --sync=s >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=8 --sync=s >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=12 --sync=s >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=16 --sync=s >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=24 --sync=s >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=1 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=2 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=8 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=12 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=16 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=24 --sync=m >>lab2b_list.csv

./lab2_list --iterations=1 --threads=1 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=2 --threads=1 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=4 --threads=1 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=8 --threads=1 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=16 --threads=1 --yield=id --lists=4 >>lab2b_list.csv

./lab2_list --iterations=1 --threads=2 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=2 --threads=2 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=4 --threads=2 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=8 --threads=2 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=16 --threads=2 --yield=id --lists=4 >>lab2b_list.csv

./lab2_list --iterations=1 --threads=4 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=2 --threads=4 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=4 --threads=4 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=8 --threads=4 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=16 --threads=4 --yield=id --lists=4 >>lab2b_list.csv

./lab2_list --iterations=1 --threads=8 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=2 --threads=8 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=4 --threads=8 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=8 --threads=8 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=16 --threads=8 --yield=id --lists=4 >>lab2b_list.csv

./lab2_list --iterations=1 --threads=16 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=2 --threads=16 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=4 --threads=16 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=8 --threads=16 --yield=id --lists=4 >>lab2b_list.csv
./lab2_list --iterations=16 --threads=16 --yield=id --lists=4 >>lab2b_list.csv

./lab2_list --iterations=10 --threads=1 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=20 --threads=1 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=40 --threads=1 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=80 --threads=1 --yield=id --lists=4 --sync=s >>lab2b_list.csv

./lab2_list --iterations=10 --threads=2 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=20 --threads=2 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=40 --threads=2 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=80 --threads=2 --yield=id --lists=4 --sync=s >>lab2b_list.csv

./lab2_list --iterations=10 --threads=4 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=20 --threads=4 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=40 --threads=4 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=80 --threads=4 --yield=id --lists=4 --sync=s >>lab2b_list.csv

./lab2_list --iterations=10 --threads=8 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=20 --threads=8 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=40 --threads=8 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=80 --threads=8 --yield=id --lists=4 --sync=s >>lab2b_list.csv

./lab2_list --iterations=10 --threads=12 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=20 --threads=12 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=40 --threads=12 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=80 --threads=12 --yield=id --lists=4 --sync=s >>lab2b_list.csv

./lab2_list --iterations=10 --threads=16 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=20 --threads=16 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=40 --threads=16 --yield=id --lists=4 --sync=s >>lab2b_list.csv
./lab2_list --iterations=80 --threads=16 --yield=id --lists=4 --sync=s >>lab2b_list.csv

./lab2_list --iterations=10 --threads=1 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=20 --threads=1 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=40 --threads=1 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=80 --threads=1 --yield=id --lists=4 --sync=m >>lab2b_list.csv

./lab2_list --iterations=10 --threads=2 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=20 --threads=2 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=40 --threads=2 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=80 --threads=2 --yield=id --lists=4 --sync=m >>lab2b_list.csv

./lab2_list --iterations=10 --threads=4 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=20 --threads=4 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=40 --threads=4 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=80 --threads=4 --yield=id --lists=4 --sync=m >>lab2b_list.csv

./lab2_list --iterations=10 --threads=8 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=20 --threads=8 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=40 --threads=8 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=80 --threads=8 --yield=id --lists=4 --sync=m >>lab2b_list.csv

./lab2_list --iterations=10 --threads=12 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=20 --threads=12 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=40 --threads=12 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=80 --threads=12 --yield=id --lists=4 --sync=m >>lab2b_list.csv

./lab2_list --iterations=10 --threads=16 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=20 --threads=16 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=40 --threads=16 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=80 --threads=16 --yield=id --lists=4 --sync=m >>lab2b_list.csv

./lab2_list --iterations=1 --threads=4 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=2 --threads=4 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=4 --threads=4 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=8 --threads=4 --yield=id --lists=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=16 --threads=4 --yield=id --lists=4 --sync=m >>lab2b_list.csv



./lab2_list --iterations=1000 --threads=1 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=4 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=8 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=12 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=16 --sync=m >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=24 --sync=m >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=1 --sync=s --lists=1 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=1 --sync=s --lists=2 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=1 --sync=s --lists=4 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=1 --sync=s --lists=8 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=1 --sync=s --lists=16 >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=2 --sync=s --lists=1 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=2 --sync=s --lists=2 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=2 --sync=s --lists=4 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=2 --sync=s --lists=8 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=2 --sync=s --lists=16 >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=4 --sync=s --lists=1 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=4 --sync=s --lists=2 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=4 --sync=s --lists=4 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=4 --sync=s --lists=8 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=4 --sync=s --lists=16 >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=8 --sync=s --lists=1 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=8 --sync=s --lists=2 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=8 --sync=s --lists=4 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=8 --sync=s --lists=8 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=8 --sync=s --lists=16 >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=12 --sync=s --lists=1 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=12 --sync=s --lists=2 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=12 --sync=s --lists=4 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=12 --sync=s --lists=8 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=12 --sync=s --lists=16 >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=1 --sync=m --lists=1 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=1 --sync=m --lists=2 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=1 --sync=m --lists=4 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=1 --sync=m --lists=8 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=1 --sync=m --lists=16 >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=2 --sync=m --lists=1 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=2 --sync=m --lists=2 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=2 --sync=m --lists=4 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=2 --sync=m --lists=8 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=2 --sync=m --lists=16 >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=4 --sync=m --lists=1 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=4 --sync=m --lists=2 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=4 --sync=m --lists=4 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=4 --sync=m --lists=8 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=4 --sync=m --lists=16 >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=8 --sync=m --lists=1 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=8 --sync=m --lists=2 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=8 --sync=m --lists=4 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=8 --sync=m --lists=8 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=8 --sync=m --lists=16 >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=12 --sync=m --lists=1 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=12 --sync=m --lists=2 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=12 --sync=m --lists=4 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=12 --sync=m --lists=8 >>lab2b_list.csv
./lab2_list --iterations=1000 --threads=12 --sync=m --lists=16 >>lab2b_list.csv



./lab2_list --iterations=1000 --threads=4 --sync=m >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=8 --sync=m >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=12 --sync=m >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=16 --sync=m >>lab2b_list.csv

./lab2_list --iterations=1000 --threads=24 --sync=m >>lab2b_list.csv
